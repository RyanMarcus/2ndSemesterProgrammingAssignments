package edu.brandeis.cs12b.PA7;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class KnowledgeBaseTest {
	
	
	@Test
	public void test1() {
		KnowledgeBase kb = new KnowledgeBase();
		
		kb.storeIsA("watermelon", "fruit");
		kb.storeIsA("apple", "fruit");
		kb.storeIsA("fuji", "apple");
		
		assertTrue("a watermelon is a fruit", kb.isA("watermelon", "fruit"));
		assertTrue("an apple is a fruit", kb.isA("apple", "fruit"));
		assertTrue("a fuji is a fruit", kb.isA("fuji", "fruit"));
		
		assertFalse("a fruit is not a watermelon", kb.isA("fruit", "watermelon"));


	}
	
	@Test
	public void test2() {
		KnowledgeBase kb = new KnowledgeBase();
		
		kb.storeIsA("alpha", "greek letter");
		kb.storeIsA("beta", "greek letter");
		kb.storeIsA("gamma", "greek letter");
		kb.storeIsA("a", "roman letter");
		kb.storeIsA("b", "roman letter");
		kb.storeIsA("c", "roman letter");
		
		kb.storeIsA("greek letter", "letter");
		kb.storeIsA("roman letter", "letter");


		
		assertTrue("an alpha is a letter", kb.isA("alpha", "letter"));
		assertTrue("a b is a roman letter", kb.isA("b", "roman letter"));
		assertTrue("a greek letter is a letter", kb.isA("greek letter", "letter"));
		
		assertFalse("a b is not a greek letter", kb.isA("b", "greek letter"));


	}
	
	@Test
	public void test3() {
		KnowledgeBase kb = new KnowledgeBase();
		
		kb.storeIsA("CS12b", "Brandeis course");
		kb.storeIsA("CS50", "Harvard course");
		kb.storeIsA("CS227", "Arizona course");
		kb.storeIsA("Pinnapple", "Fruit");
		kb.storeIsA("Harvard course", "private college course");
		kb.storeIsA("Brandeis course", "private college course");
		kb.storeIsA("Arizona course", "public college course");
		kb.storeIsA("private college course", "college course");
		kb.storeIsA("public college course", "college course");
		kb.storeIsA("college course", "course");



		
		assertTrue("CS12b is a course", kb.isA("CS12b", "course"));
		assertTrue("Arizona course is a public course", kb.isA("Arizona course", "public college course"));
		assertTrue("a pinnapple is a fruit", kb.isA("Pinnapple", "Fruit"));
		
		assertFalse("a course is not CS50", kb.isA("course", "CS50"));

	}
	
	@Test
	public void tes43() {
		KnowledgeBase kb = new KnowledgeBase();
		
		kb.storeIsA("time flies like", "an arrow");
		kb.storeIsA("fruit flies like", "a banana");
		kb.storeIsA("a banana", "fruit");
		kb.storeIsA("Ryan", "TA");
	
		
		assertFalse("closed world assumption", kb.isA("something", "something else"));

	}
}
