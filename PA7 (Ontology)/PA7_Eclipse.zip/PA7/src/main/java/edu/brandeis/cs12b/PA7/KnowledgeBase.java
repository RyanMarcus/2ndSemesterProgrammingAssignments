package edu.brandeis.cs12b.PA7;

public class KnowledgeBase {
	
	
	public void storeIsA(String type, String supertype) {
		// TODO implement me
		
	}
	
	public boolean isA(String type, String supertype) {
		// TODO implement me!
		return false;
	}
	
	
}
