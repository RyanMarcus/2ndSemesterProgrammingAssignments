package edu.brandeis.cs12b.pa4.reductions;

import edu.brandeis.cs12b.pa4.data.Data;

/**
 * Compute the median of the dataset. You may wish to override the "reduce" method
 * here.
 * 
 *
 */
public class MedianReduction extends Reduction {

	@Override
	public double reduce(Data d) {
		// TODO implement me
		return 0.0;
	}

	@Override
	protected double accum(double prev, double next) {
		return 0;
	}

	@Override
	protected double initialValue() {
		return 0;
	}

}
