package edu.brandeis.cs12b.pa4.mappings;

import edu.brandeis.cs12b.pa4.data.Data;

/**
 * Here, you will implement a mapper that normalizes the values of a dataset to be
 * in between 0 and 1. To do this, apply to each data item the following formula:
 * 
 * norm = (x_i - min(x)) / (max(x) - min(x))
 * 
 * You should compute the minimum and maximum of the dataset in the constructor, taking
 * advantage of your MinReduction and MaxReduction classes.
 * 
 * 
 *
 */
public class UnitNormMapping implements Mapping {
	
	
	
	public UnitNormMapping(Data d) {
		// TODO implement me

	}
	
	@Override
	public double mapItem(double d) {
		// TODO implement me
		return 0.0;
	}

}
