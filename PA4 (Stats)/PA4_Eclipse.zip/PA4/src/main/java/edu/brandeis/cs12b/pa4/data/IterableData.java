package edu.brandeis.cs12b.pa4.data;

import java.util.Iterator;

/**
 * Here, you will implement a wrapper class that takes in a
 * Data object and makes it iterable by adding an iterator method. The
 * iterator method should return a new Iterator<Double> object with appropriate
 * "hasNext" and "next" methods.
 * 
 *
 */
public class IterableData implements Iterable<Double> {

	
	/**
	 * Takes in a data object such that the iterator() method will
	 * return an iterator over that object.
	 * 
	 * @param d the data object to iterate over
	 */
	public IterableData(Data d) {
		// TODO implement me!
	}
	
	@Override
	public Iterator<Double> iterator() {
		// below is the syntax for creating and returning a new
		// anonymous class. See here for more info: https://docs.oracle.com/javase/tutorial/java/javaOO/anonymousclasses.html
	
		return new Iterator<Double>() {

			@Override
			public boolean hasNext() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public Double next() {
				// TODO Auto-generated method stub
				return null;
			}
			
		};
	}

}
