package edu.brandeis.cs12b.pa4.data;

import java.io.FileNotFoundException;

/**
 * This class should read data from a file and represent it as a data object.
 * The constructer will take in a filename, and you should read in files formatted in
 * this way:
 * 
 * 1.0
 * 2.0
 * 4.0
 * 90.0
 * -1.0
 * 
 * In other words, each line contains a single entry.
 * 
 *
 */
public class FileData extends Data {

	
	/**
	 * Construct a new data object from the file specified by the past filename in the
	 * format described above.
	 * @param filename the filename passed.
	 * @throws FileNotFoundException if the file doesn't exist
	 */
	public FileData(String filename) throws FileNotFoundException {
		super(filename);
		// TODO implement me!
	
	}

	@Override
	public int getLength() {
		// TODO implement me!
		return 0;
	}

	@Override
	public double getValueAt(int index) {
		// TODO implement me!
		return 0.0;
	}

}
