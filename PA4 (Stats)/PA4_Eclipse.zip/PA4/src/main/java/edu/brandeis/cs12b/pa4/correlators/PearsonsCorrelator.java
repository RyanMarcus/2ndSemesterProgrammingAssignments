package edu.brandeis.cs12b.pa4.correlators;

import edu.brandeis.cs12b.pa4.data.Data;

/**
 * Computes the Pearson's correlation between two samples, as defined here:
 * https://en.wikipedia.org/wiki/Pearson_product-moment_correlation_coefficient#For_a_sample 
 *
 */
public class PearsonsCorrelator implements Correlator {

	@Override
	public double correlate(Data d1, Data d2) {
		// TODO implement me!
		return 0.0;

	}

}
