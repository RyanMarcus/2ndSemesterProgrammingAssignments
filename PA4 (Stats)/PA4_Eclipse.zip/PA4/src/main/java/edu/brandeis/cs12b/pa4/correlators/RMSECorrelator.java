package edu.brandeis.cs12b.pa4.correlators;

import edu.brandeis.cs12b.pa4.data.Data;

/**
 * Computes the root mean squared error between two samples, defined as
 * the square root of the average squared error between each datapoint.
 * 
 * sqrt(sum((x_i - y_i)^2) / n)
 * 
 *
 */
public class RMSECorrelator implements Correlator {

	@Override
	public double correlate(Data d1, Data d2) {
		// TODO implement me!
		return 0.0;
	}

}
