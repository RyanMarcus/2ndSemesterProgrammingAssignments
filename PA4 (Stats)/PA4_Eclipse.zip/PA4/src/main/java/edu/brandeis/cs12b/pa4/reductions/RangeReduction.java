package edu.brandeis.cs12b.pa4.reductions;

import edu.brandeis.cs12b.pa4.data.Data;

/**
 * Return the range of the dataset (the difference between the maximum and the
 * minimum). You should override reduce and use your MinReduction and MaxReduction 
 * classes.
 *
 */
public class RangeReduction extends Reduction {

	@Override
	public double reduce(Data d) {
		// TODO implement me
		return 0.0;
	}

	@Override
	protected double accum(double prev, double next) {
		return 0;
	}

	@Override
	protected double initialValue() {
		return 0;
	}

	

}
