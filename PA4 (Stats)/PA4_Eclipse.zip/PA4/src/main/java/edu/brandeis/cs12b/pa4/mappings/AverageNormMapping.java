package edu.brandeis.cs12b.pa4.mappings;

import edu.brandeis.cs12b.pa4.data.Data;

/**
 * Here, you will implement an average norm mapping. Divide each datapoint by the
 * average of the entire dataset provided in the constructor. You should compute the average of the dataset in the
 * constructor.
 * 
 *
 */
public class AverageNormMapping implements Mapping {

	
	
	public AverageNormMapping(Data d) {
		// TODO implement me
	}
	
	@Override
	public double mapItem(double d) {
		// TODO implement me
		return 0.0;
	}

}
