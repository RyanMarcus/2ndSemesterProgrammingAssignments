package edu.brandeis.cs12b.pa4.reductions;

/**
 * Return the sum of the dataset. Do not override "reduce".
 * 
 *
 */
public class SumReduction extends Reduction {

	@Override
	protected double accum(double prev, double next) {
		// TODO implement me
		return 0.0;	
	}

	@Override
	protected double initialValue() {
		// TODO implement me
		return 0.0;
	}

}
