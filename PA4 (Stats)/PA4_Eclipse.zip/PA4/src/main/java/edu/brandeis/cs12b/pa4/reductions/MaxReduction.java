package edu.brandeis.cs12b.pa4.reductions;

/**
 * Compute the maximum value of a dataset
 * 
 * Do not override the "reduce" method.
 *
 */
public class MaxReduction extends Reduction {

	@Override
	protected double accum(double prev, double next) {
		// TODO implement me
		return 0.0;
	}

	@Override
	protected double initialValue() {
		// TODO implement me
		return 0.0;
	}

	

}
