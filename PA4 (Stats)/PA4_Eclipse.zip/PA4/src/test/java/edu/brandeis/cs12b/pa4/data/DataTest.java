package edu.brandeis.cs12b.pa4.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.Iterator;

import org.junit.Test;

public class DataTest {

	@Test
	public void testMemoryData() {
		Data d1 = new MemoryData("d1", new double[] {1.0, 2.0, 3.0});
		assertEquals(d1.getLength(), 3);
		assertEquals(1.0, d1.getValueAt(0), 0.0);
		assertEquals(2.0, d1.getValueAt(1), 0.0);
		assertEquals(3.0, d1.getValueAt(2), 0.0);
	}
	
	@Test
	public void testIterableData() {
		Data d1 = new MemoryData("d1", new double[] {1.0, 2.0, 3.0});
		Iterator<Double> i = (new IterableData(d1)).iterator();
		
		
		assertTrue(i.hasNext());
		assertEquals(1.0, i.next(), 0.0);
		
		assertTrue(i.hasNext());
		assertEquals(2.0, i.next(), 0.0);
		
		assertTrue(i.hasNext());
		assertEquals(3.0, i.next(), 0.0);
		
		assertFalse(i.hasNext());
	}
	
	@Test
	public void testFileData() throws FileNotFoundException {
		Data d1 = new FileData("test.dat");
		
		assertEquals(d1.getLength(), 4);
		assertEquals(2.0, d1.getValueAt(0), 0.0);
		assertEquals(4.0, d1.getValueAt(1), 0.0);
		assertEquals(6.0, d1.getValueAt(2), 0.0);
		assertEquals(8.0, d1.getValueAt(3), 0.0);

	}

}
