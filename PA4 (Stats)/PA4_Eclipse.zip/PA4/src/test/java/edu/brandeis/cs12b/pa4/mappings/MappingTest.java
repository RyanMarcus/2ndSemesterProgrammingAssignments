package edu.brandeis.cs12b.pa4.mappings;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.brandeis.cs12b.pa4.data.Data;
import edu.brandeis.cs12b.pa4.data.MemoryData;

public class MappingTest {

	Data d1;

	@Before
	public void setUp() throws Exception {
		d1 = new MemoryData("d1", new double[] {0.0, 1.0, 2.0, 30.0});
	
	}
	
	@Test
	public void testUnitNormMapping() {
		Data r = (new UnitNormMapping(d1)).map(d1);
		
		assertEquals(4, r.getLength());
		assertEquals(0.0, r.getValueAt(0), 0.01);
		assertEquals(0.033, r.getValueAt(1), 0.01);
		assertEquals(0.066, r.getValueAt(2), 0.01);
		assertEquals(1.0, r.getValueAt(3), 0.01);

	}
	
	@Test
	public void AverageNormMapping() {
		Data r = (new AverageNormMapping(d1)).map(d1);
		
		
		assertEquals(4, r.getLength());
		assertEquals(0.0, r.getValueAt(0), 0.01);
		assertEquals(0.12, r.getValueAt(1), 0.01);
		assertEquals(0.24, r.getValueAt(2), 0.01);
		assertEquals(3.63, r.getValueAt(3), 0.01);
	}
}
