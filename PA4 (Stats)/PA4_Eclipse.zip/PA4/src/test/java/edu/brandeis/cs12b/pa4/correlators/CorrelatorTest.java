package edu.brandeis.cs12b.pa4.correlators;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.brandeis.cs12b.pa4.data.Data;
import edu.brandeis.cs12b.pa4.data.MemoryData;

public class CorrelatorTest {

	Data d1, d2;
	
	@Before
	public void setUp() throws Exception {
		d1 = new MemoryData("d1", new double[] {0.0, 1.0, 2.0, 3.0, 4.0,   5.0,  6.0,  7.0});
		d2 = new MemoryData("d2", new double[] {6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, -1000.0});

	}

	@Test
	public void testPearsons() {
		double r = (new PearsonsCorrelator()).correlate(d1, d2);
		
		assertEquals(1.0, r, 0.05);
	}
	
	@Test
	public void testRMSE() {
		double r = (new RMSECorrelator()).correlate(d1, d2);
		
		assertEquals(6.0, r, 0.1);
	}

}
