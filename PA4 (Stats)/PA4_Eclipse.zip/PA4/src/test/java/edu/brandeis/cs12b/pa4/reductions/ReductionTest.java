package edu.brandeis.cs12b.pa4.reductions;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import edu.brandeis.cs12b.pa4.data.Data;
import edu.brandeis.cs12b.pa4.data.MemoryData;

public class ReductionTest {

	Data d1, d2, d3;

	@Before
	public void setUp() throws Exception {
		d1 = new MemoryData("d1", new double[] {0.0, 1.0, 2.0, 30.0});
		d2 = new MemoryData("d2", new double[] {-10.0, 12.0, 2.0, 30.0});
		d3 = new MemoryData("d3", new double[] {-100.0, 1.0, 50.75, 2.0, 300.0});

	}


	@Test
	public void testMax() {
		Reduction r = new MaxReduction();

		assertEquals(30.0, r.reduce(d1), 0.0);
		assertEquals(30.0, r.reduce(d2), 0.0);
		assertEquals(300.0, r.reduce(d3), 0.0);

	}

	@Test
	public void testMean() {
		Reduction r = new MeanReduction();

		assertEquals(8.25, r.reduce(d1), 0.01);
		assertEquals(8.5, r.reduce(d2), 0.01);
		assertEquals(50.75, r.reduce(d3), 0.01);

	}

	@Test
	public void testMedian() {
		Reduction r = new MedianReduction();

		assertEquals(1.5, r.reduce(d1), 0.01);
		assertEquals(7.0, r.reduce(d2), 0.01);
		assertEquals(2.0, r.reduce(d3), 0.01);
	}

	@Test
	public void testMin() {
		Reduction r = new MinReduction();

		assertEquals(0.0, r.reduce(d1), 0.0);
		assertEquals(-10.0, r.reduce(d2), 0.0);
		assertEquals(-100.0, r.reduce(d3), 0.0);

	}

	@Test
	public void testRange() {
		Reduction r = new RangeReduction();

		assertEquals(30.0, r.reduce(d1), 0.0);
		assertEquals(40.0, r.reduce(d2), 0.0);
		assertEquals(400.0, r.reduce(d3), 0.0);

	}

	@Test
	public void testSum() {
		Reduction r = new SumReduction();

		assertEquals(33.0, r.reduce(d1), 0.0);
		assertEquals(34.0, r.reduce(d2), 0.0);
		assertEquals(253.75, r.reduce(d3), 0.01);
	}


}
