package edu.brandeis.cs12b.pa4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import edu.brandeis.cs12b.pa4.correlators.CorrelatorTest;
import edu.brandeis.cs12b.pa4.data.DataTest;
import edu.brandeis.cs12b.pa4.mappings.MappingTest;
import edu.brandeis.cs12b.pa4.reductions.ReductionTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   DataTest.class,
   MappingTest.class,
   ReductionTest.class,
   CorrelatorTest.class
})
public class AllTests {



}
