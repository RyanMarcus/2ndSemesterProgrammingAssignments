package edu.brandeis.cs12b.pa8;

import java.io.File;
import java.io.IOException;

public class Decompress extends Decompresser {

	/**
	 * Here, you will be given a file that was produced by your Compress class. You should read from that file
	 * and transform the compressed information back into an array of strings.
	 * 
	 * @param f the file created by your compressor
	 * @return the original array of strings, modulo ordering 
	 * @throws IOException 
	 */
	public String[] decompress(File f) throws IOException {
		// TODO implement me!
		return null;
	}

}
