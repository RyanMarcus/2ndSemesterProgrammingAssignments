package edu.brandeis.cs12b.pa2;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.brandeis.cs12b.pa2.provided.GameOf15;

public class ComputerPlayerTest {

	
	private PrintStream sysOut;
	private ByteArrayOutputStream outContent;
	
	@Before
	public void setUp() throws Exception {
		sysOut = System.out;
		outContent = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outContent));
	}

	@After
	public void tearDown() throws Exception {
		System.setOut(sysOut);
	}
	
	@Test
	public void test1() {
		GameOf15 gof = new GameOf15( new int[][] 
				{{1, 2, 3, 4},
			{5, 6, 7, 8},
			{9, 10, 12, 0},
			{13, 14, 11, 15}});
		
		ComputerPlayer comp = new ComputerPlayer();
		gof = comp.solve(gof);
		
		assertEquals(gof.getValue(GameOf15.NUM_ROWS - 1, GameOf15.NUM_COLS - 1), 0);
		
	}
	
	@Test
	public void test2() {
		for (int i = 0; i < 1000; i++) {
			GameOf15 gof = new GameOf15();

			ComputerPlayer comp = new ComputerPlayer();
			gof = comp.solve(gof);

			assertEquals(gof.getValue(GameOf15.NUM_ROWS - 1, GameOf15.NUM_COLS - 1), 0);
		}
	}

}
