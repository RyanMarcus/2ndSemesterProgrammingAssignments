package edu.brandeis.cs12b.pa2;

import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.brandeis.cs12b.pa2.provided.GameOf15;

public class HumanPlayerTest {

	private static final String newLine = System.getProperty("line.separator");
	
	private InputStream sysIn;
	private PrintStream sysOut;

	private ByteArrayOutputStream outContent;

	@Before
	public void setUp() throws Exception {
		sysOut = System.out;
		sysIn = System.in;

		outContent = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outContent));
	}

	@After
	public void tearDown() throws Exception {
		System.setIn(sysIn);
		System.setOut(sysOut);
	}

	@Test
	public void test1() {
		GameOf15 gof = new GameOf15( new int[][] 
				{{1, 2, 3, 4},
			{5, 6, 7, 8},
			{9, 10, 11, 12},
			{13, 14, 0, 15}});
		
		
		String text = "l" + newLine;
		System.setIn(new ByteArrayInputStream(text.getBytes()));

		
		HumanPlayer hp = new HumanPlayer();
		hp.play(gof);
		
		assertTrue(outContent.toString().endsWith("You win!" + newLine));
		
	}
	
	@Test
	public void test2() {
		GameOf15 gof = new GameOf15( new int[][] 
				{{1, 2, 3, 4},
			{5, 6, 7, 8},
			{9, 10, 0, 12},
			{13, 14, 11, 15}});
		
		
		String text = "u" + newLine + "l" + newLine;
		System.setIn(new ByteArrayInputStream(text.getBytes()));

		
		HumanPlayer hp = new HumanPlayer();
		hp.play(gof);
		
		assertTrue(outContent.toString().endsWith("You win!" + newLine));
		
	}
	
	@Test
	public void test3() {
		GameOf15 gof = new GameOf15( new int[][] 
				{{1, 2, 3, 4},
			{5, 6, 7, 8},
			{9, 10, 12, 0},
			{13, 14, 11, 15}});
		
		
		String text = "r" + newLine + "u" + newLine + "l" + newLine;
		System.setIn(new ByteArrayInputStream(text.getBytes()));

		
		HumanPlayer hp = new HumanPlayer();
		hp.play(gof);
		
		assertTrue(outContent.toString().endsWith("You win!" + newLine));
		
	}
	
	@Test
	public void test4() {
		GameOf15 gof = new GameOf15( new int[][] 
				{{1, 0, 3, 4},
			{5, 2, 7, 8},
			{10, 6, 11, 12},
			{9, 13, 14, 15}});
		
		
		
		String text = "u" + newLine + "u" + newLine + "r" + newLine + "u" + newLine + "l" + newLine + "l" + newLine + "l" + newLine;
		System.setIn(new ByteArrayInputStream(text.getBytes()));

		
		HumanPlayer hp = new HumanPlayer();
		hp.play(gof);
		
		assertTrue(outContent.toString().endsWith("You win!" + newLine));
		
	}



	
}
