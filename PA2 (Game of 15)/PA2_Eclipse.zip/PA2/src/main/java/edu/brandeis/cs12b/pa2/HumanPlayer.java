package edu.brandeis.cs12b.pa2;

import edu.brandeis.cs12b.pa2.provided.GameOf15;

public class HumanPlayer {

	public static void main(String[] args) {
		GameOf15 gof = new GameOf15();
		HumanPlayer hp = new HumanPlayer();
		
		hp.play(gof);
	}
	
	/**
	 * Here, you must implement a command-line interface to the 15-puzzle game.
	 * 
	 * You should ask the user for moves and execute them on the provided board
	 * until the puzzle has been solved. The move commands are:
	 * 
	 * u -- move up
	 * d -- move down
	 * l -- move left (that's an L, not an I)
	 * r -- move right
	 * 
	 * @param args
	 */
	public void play(GameOf15 gof) {
		// TODO implement me!

	}

}
