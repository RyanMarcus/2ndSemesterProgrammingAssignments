package edu.brandeis.cs12b.pa5;

/**
 * The router class takes in a Grpah object and then
 * allows the user to find routes between places represented by
 * the graph.
 * 
 *
 */
public class Router {


	/**
	 * Constructs a new Router object with the given graph
	 * @param graph the graph to route on
	 */
	public Router(Graph graph) {

	}

	/**
	 * Returns an iterable over the vertices along a valid path
	 * between vertex "start" and vertex "end" in the graph.
	 * 
	 * If no route exists, return null.
	 * 
	 * 
	 * @param start the start position
	 * @param end the desired end position
	 * @return the vertices along a path
	 */
	public Iterable<String> getRoute(String start, String end) {
		return null;
	}



	/**
	 * Same as the above method, but the route returned
	 * must be a valid path and there must not be any path shorter
	 * than it (it must be the shortest path, potentially not a unique one).
	 * 
	 * You should use Dijkstra's algorithm: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
	 * 
	 * @param start the starting location
	 * @param end the end location
	 * @return the shortest path between start and end
	 */
	public Iterable<String> getShortestRoute(String start, String end) {
		return null;
	}
}
