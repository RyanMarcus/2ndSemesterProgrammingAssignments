package edu.brandeis.cs12b.pa5;

/**
 * Hello world!
 *
 */
public class Graph {	


	/**
	 * Construct a new graph object using the fdp-formatted graph
	 * provided as a string.
	 * 
	 * The format looks like this:
	 * 
	 *  graph g {
	 *  "a" -- "b" [ label = "10" ];
	 *  "b" -- "c" [ label = "20" ];
	 *  }
	 *  
	 *  To represent that vertex A is connected to vertex B with
	 *  a weight of 10, and B is connected to C with weight 20.
	 *
	 * @param fdp the graph to construct
	 */
	public Graph(String fdp) {
		

	}


	/**
	 * Get the weight of the edge between vertex a and vertex b.
	 * 
	 * If there is no edge connecting the two vertices, return -1.
	 * @param a one vertex
	 * @param b another
	 * @return the edge weight
	 */
	public int getEdgeWeight(String a, String b) {

		return -1;
	}

	/**
	 * Return an iterable object that will iterate over
	 * the vertices directly connected to vertex A
	 * @param a the vertex
	 * @return an iterator of strings that A is connected to
	 */
	public Iterable<String> getConnectedEdges(String a) {
		return null;
	}

	/**
	 * Gets the length of the path (sum of the edge weights)
	 * represented by the passed iterable. If the path is invalid,
	 * (jumps between non-connected vertices), return -1
	 * @param path an iterable of vertices
	 * @return the path length
	 */
	public int getPathLength(Iterable<String> path) {
		return -1;
	}
	
	/**
	 * Returns an iterable over all the vertices in the graoh
	 * @return the vertices
	 */
	public Iterable<String> getVertices() {
		return null;
	}



}
