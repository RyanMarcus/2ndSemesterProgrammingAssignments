package edu.brandeis.cs12b.pa5;

public class SpanningTree {

	public class Edge {
		public String vertex1;
		public String vertex2;
		public int weight;
		
	}
	

	/**
	 * Calculate the minimum spanning tree of the graph,
	 * which is the set of edges with the smallest weight
	 * sum that connect all the vertices of the graph such that
	 * there is a path from each vertex to every other vertex.
	 * 
	 * @param g the graph
	 * @return an iterable over the edges in the MST
	 */
	public Iterable<Edge> getMST(Graph g) {
		return null;
	}
}
