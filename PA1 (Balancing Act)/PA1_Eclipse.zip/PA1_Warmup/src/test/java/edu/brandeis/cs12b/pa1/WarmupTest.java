package edu.brandeis.cs12b.pa1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class WarmupTest {

	
	@Test
	public void countRepeatsTest() {
		assertEquals(1, WarmupProblems.countRepeats(new int[] {1, 1, 1, 2}));
		assertEquals(2, WarmupProblems.countRepeats(new int[] {1, 1, 1, 2, 2}));
		assertEquals(3, WarmupProblems.countRepeats(new int[] {1, 1, 1, 2, 2, 4, 6, 6}));

		
		assertEquals(0, WarmupProblems.countRepeats(new int[] {1, 2, 3, 4, 5, 6, 7, 8}));

	}
	
	@Test
	public void ParensBalanceTest() {
		assertTrue(WarmupProblems.parensBalance(""));
		assertTrue(WarmupProblems.parensBalance("()"));
		assertTrue(WarmupProblems.parensBalance("()()()()"));
		assertTrue(WarmupProblems.parensBalance("((()()))"));

		assertFalse(WarmupProblems.parensBalance("((()())"));
		assertFalse(WarmupProblems.parensBalance("((().())"));
		assertFalse(WarmupProblems.parensBalance(")()("));
	}
	
	@Test
	public void sum3Test() {
		assertTrue(WarmupProblems.sum3(new int[] { -20, 10, 15, 5}));
		assertTrue(WarmupProblems.sum3(new int[] { -60, 20, 10, 40}));
		assertTrue(WarmupProblems.sum3(new int[] {-20, -10, -4, 20, 10, 14}));
		
		assertFalse(WarmupProblems.sum3(new int[] {-20, -10, -40, 20, 10, 15}));
		assertFalse(WarmupProblems.sum3(new int[] {5, 6, 7, 8, 12, 13, 4, 21, 4}));
		assertFalse(WarmupProblems.sum3(new int[] {5, 6, -7, 8, 12, 13, 4, 21, -4}));


		
	}
	
	@Test
	public void ParensBracketsBalanceTest() {
		assertTrue(WarmupProblems.parensBracketsBalance(""));
		assertTrue(WarmupProblems.parensBracketsBalance("()"));
		assertTrue(WarmupProblems.parensBracketsBalance("()()()()"));
		assertTrue(WarmupProblems.parensBracketsBalance("((()()))"));

		assertFalse(WarmupProblems.parensBracketsBalance("((()())"));
		assertFalse(WarmupProblems.parensBracketsBalance("((().())"));
		assertFalse(WarmupProblems.parensBracketsBalance(")()("));
		
		
		assertTrue(WarmupProblems.parensBracketsBalance("[]"));
		assertTrue(WarmupProblems.parensBracketsBalance("[()]"));
		assertTrue(WarmupProblems.parensBracketsBalance("()[()()]()"));
		assertTrue(WarmupProblems.parensBracketsBalance("(([[()][()]]))"));

		assertFalse(WarmupProblems.parensBracketsBalance("[(](()())"));
		assertFalse(WarmupProblems.parensBracketsBalance("[)()(]"));
	}

}
