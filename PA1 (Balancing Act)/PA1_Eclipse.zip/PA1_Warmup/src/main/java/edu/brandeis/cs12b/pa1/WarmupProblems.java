package edu.brandeis.cs12b.pa1;

public class WarmupProblems {

	
	/**
	 * Returns the number of items that have duplicates in a sorted list. For example,
	 * in the list [1, 3, 3, 5, 5, 5, 5], countRepeats should return 2, because there are
	 * two numbers that are repeated -- three and five. The numbers in the list will be
	 * between -1000 and 1000.
	 * 
	 * You may assume that the list is sorted in ascending order.
	 * 
	 * @param items the list, sorted in ascending order
	 * @return the number of repeated elements
	 */
	public static int countRepeats(int[] items) {
		// TODO implement me
		return -1;
	}
	
	
	/**
	 * Returns true if a string of parenthesis is balanced. A balanced string
	 * is a string where every "(" has a matching ")" later in the string and there are
	 * no ")" without an "(".
	 * 
	 * A string with any character beside "(" or ")" is invalid. The empty string is valid.
	 * 
	 * Examples: ()  -> TRUE (balanced)
	 *           (() -> FALSE (unmatched "(")
	 * @param s a string
	 * @return if the string is balanced
	 */
	public static boolean parensBalance(String s) {
		// TODO implement me!
		return false;
	}


	/**
	 * Return true if there are three integers in the items array that sum up to
	 * zero. Return false otherwise. THe items in the array will be unique.
	 * 
	 * Examples: [1, 3, -4, 2, -2] -> TRUE (1 + 3 + -4 = 0) [8, -6, 4, -2] ->
	 * TRUE (8 + -6 + -2 = 0) [3, 4, 1, 52] -> FALSE
	 * 
	 * Try to solve this problem in O(n^2) time -- in other words, try to only
	 * nest your for loops two levels deep. It can be done!
	 * 
	 * You may also assume that all the items are in between -100 and 100.
	 * 
	 * @param items
	 *            the items to check
	 * @return whether or not there are three integers who sum to three
	 */
	public static boolean sum3(int[] items) {
		// TODO implement me!
		return false;

	}

	/**
	 * This problem is like the previous problem, but also includes braces "[" and "]".
	 * Again, ensure that the string is balanced, but note that the addition of brackets
	 * adds some complexity. The string "[()]" is balanced, but the string "[(])" is not. 
	 * 
	 * Hint: the rules to determine if a string is balanced are as follows:
	 * 
	 *   1. The empty string is a valid string
	 *   2. If A and B are valid strings, A+B is a valid string.
	 *   3. If A is a valid string, then (A) is a valid string.
	 *   4. If A is a valid string, then [A] is a valid string.
	 * 
	 * @param s the string
	 * @return if the string is balanced
	 */
	public static boolean parensBracketsBalance(String s) {
		// TODO implement me!
		return false;
	}
}
