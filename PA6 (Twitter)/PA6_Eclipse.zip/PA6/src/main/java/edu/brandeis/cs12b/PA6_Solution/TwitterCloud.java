package edu.brandeis.cs12b.PA6_Solution;

public class TwitterCloud {
	
	/**
	 * The number of tokens you should extract from tweets
	 */
	private static final int NUMBER_TOKENS = 4000;
	
		
	public static void main(String[] a) {
		TwitterCloud tc = new TwitterCloud();
		tc.makeCloud(new String[] { "donald", "trump" }, "test.png");
	}

	public void makeCloud(String[] args, String filename) {
		// make it happen here! Feel free to throw exceptions.
	}

}
