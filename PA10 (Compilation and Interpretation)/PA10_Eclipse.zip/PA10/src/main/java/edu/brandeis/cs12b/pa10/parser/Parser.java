package edu.brandeis.cs12b.pa10.parser;

import java.util.Iterator;
import java.util.List;

import edu.brandeis.cs12b.pa10.lexer.Lexeme;

public class Parser {

	public Parser(Iterator<Lexeme> lexemes) {

	}

	public List<ParseTreeNode> parse() {
		return null;

	}

	
}
