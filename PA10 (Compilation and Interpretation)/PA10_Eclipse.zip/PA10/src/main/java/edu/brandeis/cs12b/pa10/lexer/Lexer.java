package edu.brandeis.cs12b.pa10.lexer;

import java.util.Iterator;

public class Lexer implements Iterator<Lexeme> {
	
	public Lexer(String toLex) {
		
	}


	@Override
	public boolean hasNext() {
		return false;
	}

	@Override
	public Lexeme next() {
		return null;
	}
	
	
}
