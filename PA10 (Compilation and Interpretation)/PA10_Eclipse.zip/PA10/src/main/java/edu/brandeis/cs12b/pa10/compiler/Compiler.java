package edu.brandeis.cs12b.pa10.compiler;

import java.util.List;

import edu.brandeis.cs12b.pa10.parser.ParseTreeNode;
import edu.brandeis.cs12b.vm.VMInstruction;

public class Compiler {
	
	public Compiler(List<ParseTreeNode> ptn) {
	
	}

	public List<VMInstruction> compile() {
		return null;

	}

	
}
