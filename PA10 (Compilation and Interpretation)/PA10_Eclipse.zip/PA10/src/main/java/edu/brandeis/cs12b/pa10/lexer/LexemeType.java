package edu.brandeis.cs12b.pa10.lexer;

public enum LexemeType {
	LEFT_PAREN, RIGHT_PAREN, OPERATOR, NUMBER, VARIABLE, EQUALS, SEMICOLON, USER_INPUT;
	
}
