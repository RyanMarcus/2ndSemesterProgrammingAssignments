package edu.brandeis.cs12b.pa10.interpreter;

import java.util.List;
import java.util.Map;

import edu.brandeis.cs12b.pa10.parser.ParseTreeNode;

public class Interpreter {

	
	public Interpreter(List<ParseTreeNode> ptns) {
		
	}

	public Map<String, Double> evaluate() {
		
		return null;
	}

	
}
