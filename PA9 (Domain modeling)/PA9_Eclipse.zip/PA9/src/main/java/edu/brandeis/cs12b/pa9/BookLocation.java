package edu.brandeis.cs12b.pa9;

public class BookLocation {
	private int floor;
	private int shelf;
	private int cas;

	
	public BookLocation(int floor, int cas, int shelf) {
		this.floor = floor;
		this.shelf = shelf;
		this.cas = cas;
	}
	
	public BookLocation() {
		
	}
	
	
	public int getFloor() {
		return floor;
	}
	public int getShelf() {
		return shelf;
	}
	public int getCas() {
		return cas;
	}


	public void setFloor(int floor) {
		this.floor = floor;
	}


	public void setShelf(int shelf) {
		this.shelf = shelf;
	}


	public void setCas(int cas) {
		this.cas = cas;
	}
	
	
	
}
