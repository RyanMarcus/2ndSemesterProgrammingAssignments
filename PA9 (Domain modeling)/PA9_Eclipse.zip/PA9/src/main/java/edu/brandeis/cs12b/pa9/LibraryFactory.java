package edu.brandeis.cs12b.pa9;

import java.io.File;

public final class LibraryFactory {


	/**
	 * Construct a new library object based on the given parameters
	 * @param floors the number of floors
	 * @param casesPerFloor the number of cases per floor
	 * @param shelvesPerCase the number of shelves per case on each floor
	 * @param shelfCapacity the capacity of each shelf
	 * @return a library object
	 */
	public static Library makeLibrary(int floors, int[] casesPerFloor, int[][] shelvesPerCase, int[][][] shelfCapacity) {
		
		return null;
	}
	
	/**
	 * Makes a new library from the passed file. The file will have been produced by your
	 * Library's writeToFile method.
	 * 
	 * @param f the file to read from
	 * @return the reconstructed library
	 */
	public static Library makeLibraryFromFile(File f) {
		
		return null;
	}
	
}
